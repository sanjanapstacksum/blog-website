import { Outlet } from "react-router-dom"

const AuthenticationLayout=()=>{
    return(<>
    <Outlet/></>)
}
export default AuthenticationLayout