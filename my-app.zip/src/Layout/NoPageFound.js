
import { Outlet } from "react-router-dom";

const NoPageFound = ()=>{
    return(<><Outlet/></>)
}
export default NoPageFound;